package com.example.facebook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class fblogin extends AppCompatActivity {
EditText email,pass;
Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fblogin);

        //Validation-work
//        email = findViewById(R.id.email);
//        pass = findViewById(R.id.pass);
//        btn = findViewById(R.id.btn);
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String umail = email.getText().toString();
//                String upass = pass.getText().toString();
//                if(umail.equals(""))
//                {
//                    email.setError("Email is required");
//                    return;
//                }
//                if(upass.equals(""))
//                {
//                    pass.setError("Password is requried");
//                    return;
//                }
//            }
//        });

        //Login-work
        email = findViewById(R.id.email);
        pass = findViewById(R.id.pass);
        btn = findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String myemail = email.getText().toString();
            String mypass = pass.getText().toString();

            if(myemail.equals("ashhad.ullislam@gmail.com") && mypass.equals("admin"))
            {
                Intent i = new Intent(fblogin.this,Mainfbpage.class);
                startActivity(i);
            }
            else
            {
                Toast.makeText(fblogin.this,"Invalid username or password", Toast.LENGTH_LONG).show();
            }
            }
        });
    }

}